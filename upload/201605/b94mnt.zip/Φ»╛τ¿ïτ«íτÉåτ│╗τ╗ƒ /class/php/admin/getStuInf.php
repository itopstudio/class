<?php
/**
 * Created by PhpStorm.
 * User: Ewan
 * Date: 2015/10/8
 * Time: 19:32
 */
require_once '../include.php';
if($_POST){
//print_r($_POST);
   getStuInf($_POST['gradeNum'],$_POST['select'],$D);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
    <link rel="stylesheet" href="styles/backstage.css">
</head>
<body>
<div class="details">
    <div class="details_operation clearfix">
        <div class="bui_select">
            <form action="" method="post">
           <input style="width:600px" type="text" name="gradeNum" placeholder="请输添加年级" />
                <select name="select"  >
                    <option value="0190">卓越班</option>
                    <option value="0191">IT班</option>
                    <option value="0114">大类</option>
                </select>
          <input type="submit" value="添加"  class="btn" />
            </form>
        </div>
    </div>

</div>
</body>
</html>