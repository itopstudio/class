<?php
require_once '../include.php';
$id=$_GET['id'];
//echo $id;
$sql="select * from  dd where DD_no={$id} ";
$row=myselect($sql,$D);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
</head>
<body>
<h3>修改字段</h3>
注意！每项都要填写才能修改成功哦。
<form action="doAdminAction.php?act=editDD&id=<?php echo $id;?>" method="post">
    <table width="70%" border="1" cellpadding="5" cellspacing="0" bgcolor="#cccccc">
        <tr>
            <td align="right">编号</td>
            <td><input type="text" name="DD_no" placeholder="<?php echo $row[0]['DD_no'];?>"/></td>
            <td align="right">类别</td>
            <td><input type="text" name="DD_Data_type" placeholder="<?php echo $row[0]['DD_Data_type'];?>"/></td>
            <td align="right">归属用户</td>
            <td><input type="text" name="DD_user_id" placeholder="<?php echo $row[0]['DD_user_id'];?>"/></td>
            <td align="right">是否可用</td>
            <td><input type="text" name="DD_usewhether" placeholder="<?php echo $row[0]['DD_usewhether'];?>"/></td>
            <td align="right">详细描述</td>
            <td><input type="text" name="DD_Cexplain_name" placeholder="<?php echo $row[0]['DD_Cexplain_name'];?>"/></td>
            <td align="right">remark1</td>
            <td><input type="text" name="DD_remark1" placeholder="<?php echo $row[0]['DD_remark1'];?>"/></td>
            <td align="right">remark2</td>
            <td><input type="text" name="DD_remark2" placeholder="<?php echo $row[0]['DD_remark2'];?>"/></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit"  value="修改分类"/></td>
        </tr>

    </table>
</form>
</body>
</html>