<?php
require_once '../include.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
</head>
<body>
<h3>修改分类</h3>
<form action="doAdminAction.php?act=addTeacher" method="post">
    <table width="70%" border="1" cellpadding="5" cellspacing="0" bgcolor="#cccccc">
        <tr>
            <td align="right">ID</td>
            <td><input type="text" name="teacher_ID" /></td>
            <td align="right">姓名</td>
            <td><input type="text" name="teacher_name"/></td>
            <td align="right">性别</td>
            <td><input type="text" name="teacher_sex" /></td>
            <td align="right">学校</td>
            <td><input type="text" name="teacher_school" /></td>
            <td align="right">院系</td>
            <td><input type="text" name="teacher_depart"/></td>
            <td align="right">职称</td>
            <td><input type="text" name="teacher_position" /></td>
            <td align="right">密码</td>
            <td><input type="text" name="teacher_password" /></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit"  value="添加"/></td>
        </tr>

    </table>
</form>
</body>
</html>