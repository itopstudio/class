<?php
require_once '../include.php';
$username=$_POST['username'];
$username=addslashes($username);
$password=md5($_POST['password']);
//$password=$_POST['password'];
$verify=$_POST['verify'];
$verify1=$_SESSION['verify'];
$autoFlag=$_POST['autoFlag'];
if($verify==$verify1){
    $row=select('admin','id,username,role',"id='$username'and password='$password'",$D);
//    $row=checkAdmin($sql);
//    print_r($row);
    if($row){
        //���ѡ��һ�����Զ���½
        if($autoFlag){
            setcookie("adminId",$row[0]['id'],time()+7*24*3600);
            setcookie("adminName",$row[0]['username'],time()+7*24*3600);
            setcookie('adminrole',$row[0]['role'],time()+7*24*3600);
        }
        $_SESSION['adminName']=$row[0]['username'];
        $_SESSION['adminId']=$row[0]['id'];
        $_SESSION['adminrole']=$row[0]['role'];
//        print_r($_SESSION);
        alertMes("验证成功","index.php");
    }else{
        alertMes("用户名或密码错误","login.php");
    }
}else{
    alertMes("验证码错误","login.php");
}