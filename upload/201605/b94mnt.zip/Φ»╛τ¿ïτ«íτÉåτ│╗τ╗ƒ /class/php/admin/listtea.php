<?php
require_once '../include.php';
$page=$_REQUEST['page']?(int)$_REQUEST['page']:1;
if($_GET["selecttea_name"]){
    $totalRows=getResultNum('teacher',"teacher_name LIKE '%{$_GET['selecttea_name']}%'",$D);
    $selectteaName=$_GET["selecttea_name"];
//    echo $totalRows;
}else{
    $totalRows=getResultNum('teacher','',$D);
}
//echo $totalRows;
$pageSize=10;
$totalPage=ceil($totalRows/$pageSize);
if($page<1||$page==null||!is_numeric($page))$page=1;
if($page>=$totalPage)$page=$totalPage;
$offset=($page-1)*$pageSize;
if($_GET['selecttea_name']){
    $sql="select teacher_ID,teacher_name,teacher_sex,teacher_school,teacher_depart,teacher_position from teacher where teacher_name LIKE '%{$_GET['selecttea_name']}%'order by
teacher_ID asc limit {$offset},{$pageSize}";
}else{
$sql="select teacher_ID,teacher_name,teacher_sex,teacher_school,teacher_depart,teacher_position from teacher  order by
teacher_ID asc limit {$offset},{$pageSize}";}
//echo $sql;
$rows=myselect($sql,$D);
//print_r($rows);
if(!$rows){
    alertMes("sorry,没有教师,请添加!","addCate.php");
    exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
    <link rel="stylesheet" href="styles/backstage.css">
</head>
<body>
<div class="details">
    <div class="details_operation clearfix">
        <div class="bui_select">
            <input type="button" value="添&nbsp;&nbsp;加" class="add"  onclick="addTeacher()">
        </div>
        <div>
            <form action="listtea.php" method="GET" >
                <table class="table" cellspacing="0" cellpadding="0" >
                    <tr>
                        <td align="center">模糊查询</td>
                        <td  width="600px"><input style="width:600px" type="text" name="selecttea_name" placeholder="请输入老师姓名" /></td>
                        <td align="center"><input type="submit" value="查询"  class="btn" /></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    <!--表格-->
    <table class="table" cellspacing="0" cellpadding="0">
        <thead>
        <tr>
            <th width="15%">ID</th>
            <th width="10%">姓名</th>
            <th width="10%">性别</th>
            <th width="10%">学校</th>
            <th width="10%">院系</th>
            <th width="10%">职称</th>
            <th>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php  foreach($rows as $row):?>
            <tr>
                <!--这里的id和for里面的c1 需要循环出来-->
                <td><input type="checkbox" id="c1" class="check"><label for="c1" class="label"><?php echo $row['teacher_ID'];?></label></td>
                <td><?php echo $row['teacher_name'];?></td>
                <td><?php echo $row['teacher_sex'];?></td>
                <td><?php echo $row['teacher_school'];?></td>
                <td><?php echo $row['teacher_depart'];?></td>
                <td><?php echo $row['teacher_position'];?></td>
                <td align="center"><input type="button" value="修改" class="btn" onclick="editTeacher('<?php echo $row['teacher_ID'];?>')"><input type="button" value="删除" class="btn"  onclick="delTeacher('<?php echo $row['teacher_ID'];?>')"></td>
            </tr>
        <?php endforeach;?>
        <?php if($totalRows>$pageSize):?>
            <tr>
                <td colspan="4"><?php
                    if($_GET['selecttea_name']){
                        echo showPage($page, $totalPage,"selecttea_name={$selectteaName}");
                    }else {
                        echo showPage($page, $totalPage);
                    }
                    ?></td>
            </tr>
        <?php endif;?>
        </tbody>
    </table>
</div>
<script type="text/javascript">
    function editTeacher(id){
//        id=string(id);
//        alert(id);
        window.location="editTeacher.php?id="+id;
    }
    function delTeacher(id){
        if(window.confirm("您确定要删除吗？删除之后不能恢复哦！！！")){
            window.location="doAdminAction.php?act=delTeacher&id="+id;
        }
    }
    function addTeacher(){
        window.location="addTeacher.php";
    }
</script>
</body>
</html>