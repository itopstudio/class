<?php
/**
 * Created by PhpStorm.
 * User: Ewan
 * Date: 2015/9/24
 * Time: 21:08
 */
require_once '../include.php';
if($_POST){
//    print_r($_POST);
    getAsess($_POST['teaNum'],$D);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
    <link rel="stylesheet" href="styles/backstage.css">
</head>
<body>
<div class="details">
    <div class="details_operation clearfix">
        <div class="bui_select">
            <form action="" method="post">
                <input style="width:600px" type="text" name="teaNum" placeholder="教师工号" />
                <input type="submit" value="添加"  class="btn" />
            </form>
        </div>
    </div>

</div>
</body>
</html>
