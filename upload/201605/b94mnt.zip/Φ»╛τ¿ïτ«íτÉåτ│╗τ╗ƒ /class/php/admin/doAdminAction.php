<?php
require_once '../include.php';
$act=$_REQUEST['act'];
//echo $act;
if($act=="reg"){
    $mes=reg();
}elseif($act=="login"){
    $mes=login();
}elseif($act=="logout"){
//    echo '2';
    logout();
}elseif($act=='editTeacher'){
    $row=$_POST;
    $mes=updata('teacher',$row,"teacher_ID={$row['teacher_ID']}",$D);
}elseif($act=='delTeacher'){
    $id=$_GET['id'];
    $mes=delete('teacher',"teacher_ID=$id",$D);
}elseif($act=='addTeacher'){
    $row=$_POST;
    $mes=insert('teacher',$row,$D);
}elseif($act=='addAdmin'){
   $mes= addAdmin($D);
}elseif($act=='delAdmin'){
    $mes= delAdmin($D);
}elseif($act=='editAdmin'){
    $mes= editAdmin($D);
}elseif($act=='addDD'){
    $mes=addDD($D);
}elseif($act=='editDD'){
    $mes=editDD($D);
}elseif($act=='delDD'){
    $mes= delDD($D);
}elseif($act=='setTime'){
//    echo "2";
    $mes=setTime($D);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
</head>
<body>
<?php
if($mes){
    echo $mes;
}
?>
</body>
</html>