<?php
/**
 * Created by PhpStorm.
 * User: Ewan
 * Date: 2015/8/26
 * Time: 11:18
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Insert title here</title>
</head>
<body>

<form action="doAdminAction.php?act=setTime" method="post">
   <table class="table" cellspacing="0" cellpadding="0">
       <tr>
          <th>学期信息</th>
          <th>起始日期</th>
       </tr>
       <tr>
           <td><input type="text" name="greadInf" placeholder="如15-16下学期"></td>
           <td><input type="text" name="starDay" placeholder="2015-9-7"></td>
       </tr>
       <tr>
           <td></td>
           <td align="right"><input type="submit" value="保存"></td>
       </tr>
   </table>
</form>
</body>
</html>
