<?php
/**
 * Created by PhpStorm.
 * User: Ewan
 * Date: 2015/10/17
 * Time: 13:58
 */
require_once "../include.php";
$Inf=$_POST;
// print_r($Inf);
switch ($Inf["homeTime"]){
    case 1:$time="第一次";break;
    case 2:$time="第二次";break;
    case 3:$time="第三次";break;
    case 4:$time="第四次";break;
    case 5:$time="第五次";break;
    case 6:$time="第六次";break;
    case 7:$time="第七次";break;
    case 8:$time="第八次";break;
    default:
        echo "No number between 1 and 3";
}
$flag=select("topic","*","topic_times='{$time}' and topic_tclass_no='{$Inf['Tclass_no']}' and topic_type='作业'",$D);
if($flag){
    $sql="update topic set topic_content='{$Inf['work_explain']}',topic_deadline='{$Inf['end_time']}',topic_releasetime='{$Inf['launch_time']}',topic_fullmark='{$Inf['max_score']}',topic_proportion='{$Inf['workPersent']}',topic_submission_method='{$Inf['submit_type']}',topic_times='{$time}',topic_tclass_no='{$Inf['Tclass_no']}' WHERE topic_times='{$time}' and topic_tclass_no='{$Inf['Tclass_no']}' and topic_type='作业'";
    $back = $D->exec($sql);
}else {
    $sql = "insert into topic VALUES ('{$Inf['work_explain']}','{$Inf['end_time']}','','{$Inf['launch_time']}','{$Inf['max_score']}','{$Inf['workPersent']}','{$Inf['submit_type']}','{$time}','{$Inf['Tclass_no']}','0','作业')";
    $back = $D->exec($sql);
}
// if($back){
	// $a=1;
	// $arr=json_decode($a);
	// echo $arr;
// }else{
	// $a=0;
	// $arr=json_decode($a);
	// echo $arr;
// }