<?php 
/**
 * 添加分类的操作
 * @return string
 */
function addCate(){
	$arr=$_POST;
	if(insert("imooc_cate",$arr)){
		$mes="分类添加成功!<br/><a href='addCate.php'>继续添加</a>|<a href='listCate.php'>查看分类</a>";
	}else{
		$mes="分类添加失败！<br/><a href='addCate.php'>重新添加</a>|<a href='listCate.php'>查看分类</a>";
	}
	return $mes;
}

/**
 * 根据ID得到指定分类信息
 * @param int $id
 * @return array
 */
function getTeacherById($id,$D)
{
	$sql = "select teacher_ID,teacher_name,teacher_sex,teacher_school,teacher_depart,teacher_position from teacher where
teacher_ID={$id}";
//	echo $sql;
	return myselect($sql, $D);
}
/**
 * 修改分类的操作
 * @param string $where
 * @return string
 */
function editCate($where){
	$arr=$_POST;
	if(update("imooc_cate", $arr,$where)){
		$mes="分类修改成功!<br/><a href='listCate.php'>查看分类</a>";
	}else{
		$mes="分类修改失败!<br/><a href='listCate.php'>重新修改</a>";
	}
	return $mes;
}

/**
 *删除分类
 * @param string $where
 * @return string
 */
function delCate($id){
	$res=checkProExist($id);
	if(!$res){
		$where="id=".$id;
		if(delete("imooc_cate",$where)){
			$mes="分类删除成功!<br/><a href='listCate.php'>查看分类</a>|<a href='addCate.php'>添加分类</a>";
		}else{
			$mes="删除失败！<br/><a href='listCate.php'>请重新操作</a>";
		}
		return $mes;
	}else{
		alertMes("不能删除分类，请先删除该分类下的商品", "listPro.php");
	}
}

/**
 * 得到所有分类
 * @return array
 */
function getAllCate(){
	$sql="select id,cName from imooc_cate";
	$rows=fetchAll($sql);
	return $rows;
}

/** 获取老师的课程
 *
 */
function getAsess($tea_number,$D){
//	$tea_number='019942';
//	echo $tea_number;
	$url ="http://jwzx.cqupt.edu.cn/new/labkebiao/showteakebiao2.php?tid=$tea_number";
	$content = file_get_contents($url) or die ("sdf");
	$sentense = iconv('GBK', 'UTF-8', $content) or die ("转码失败");
	$mode="/<tr>([\s\S]*)<\/tr>/U";
	$mode2="/<td class='title'>(.*)<\/td>/U";//第几节
	$mode3="/<td >&nbsp;([\s\S]*)<\/td>/U";
	$mode4="/([\s\S]*)(<br>|<BR>)/U";
	$mode7="/<font color=#ff0000>(.*)<\/font>/U";
	$mode9="/<a href='showStuList\.php\?jxb=(.*)' target=_blank>学生名单<\/a>/U";
	$mode10="/^[0-9]\d*/";
	$mode11="/[0-9]{6}(.*)/";
	preg_match_all($mode,$sentense,$matches);//抓到TR
//	error_reporting(0);
	$i=1;
	while($i<=6){
		preg_match_all($mode2,$matches[1][$i],$class);//抓到第几节
		preg_match_all($mode3,$matches[1][$i],$content1);//抓到具体的课
		$i2=0;
		while($i2<=6){
			preg_match_all($mode4,$content1[1][$i2],$element);//分解课中的元素
			preg_match_all($mode7,$content1[1][$i2],$type);//提取课的类型
			$i3=0;$i4=0;
			$i5=$i2+1;
			while($element[1][$i3]){
				preg_match_all($mode9,$element[1][$i3+6],$jiaoxueban);//获取教学班
				$sql="INSERT INTO tea_class (id,class,type,classnumber,major,tea_number,jiaoxueban) VALUES('','{$element[1][$i3]}','{$type[1][$i4]}','{$element[1][$i3+5]}','{$element[1][$i3+4]}','$tea_number','{$jiaoxueban[1][0]}')";
				$D->exec($sql);
				$i6=$i3+6;
				$i3+=8;$i4+=1;
			}
			$i2++;}
		$i++;
	}
	$sqlSelect="select * from tea_class group by jiaoxueban";
	$back=$D->query($sqlSelect);
	$back->setFetchMode(PDO::FETCH_ASSOC);
	foreach ($back as $inf){
		preg_match_all($mode10,$inf['class'],$courseNum) OR DIE ("SDF");//获取课程号
		preg_match_all($mode11,$inf['class'],$courseNam) OR DIE ("SDF");//获取课程名
		$sql="insert into assess (assess_no,assess_Course_no,assess_teacher_no,assess_explain) values ('','{$courseNum[0][0]}','$tea_number','{$courseNam[1][0]}')";//保存课程
//		echo $sql;
		$D->exec($sql);
		$id=$D->lastInsertId();
//		echo $id;
		$sql="insert into tclass(Tclass_no,Tclass_class_no,Tclass_specialty,tclass_assess_no,tclass_course_no,tclass_teacher_ID)values('{$inf['jiaoxueban']}','{$inf['classnumber']}','{$inf['major']}','$id','{$courseNum[0][0]}','$tea_number')";//保存教学班
//		echo $sql;
		if($D->exec($sql)){
			getJxbStu($inf['jiaoxueban'],$D);
		}
	}
}
function getJxbStu($jiaoxueban,$D){
//	$jiaoxueban="A011518756759";
	preg_match_all("/./U",$jiaoxueban,$flag);
	if($flag[0][0]!="S"){//实验课与理论课有差别。开头为S为实验课。
		$url ="http://jwzx.cqupt.edu.cn/showJxbStuList.php?jxb=$jiaoxueban";
		$content = file_get_contents($url) or die ("sdf");
		$sentense = iconv('GBK', 'UTF-8', $content) or die ("转码失败");
		$mode="/<tr bgcolor=(.*)><td  >(.*)<\/td><td  >(.*)<\/td><td  >(.*)<\/td>
            <td  >(.*)<\/td>
            <td  >(.*)  <\/td>
            <td  >(.*)<\/td>
            <td  >(.*)<\/td>
            <td  >(.*)<\/td>
      <\/tr>/U";
// print_r ($sentense);
		preg_match_all($mode,$sentense,$match);
//		echo count($match[1]);
		for ($i=0;$i<=count($match[1])-1;$i++){
			$sql="insert into ref_tclass_student (ref_T_S_Tclass_no,ref_T_S_student_ID,student_type) values ('$jiaoxueban','{$match[4][$i]}','{$match[9][$i]}')";
			$D->exec($sql);
		}

	}else{
		$url ="http://jwzx.cqupt.edu.cn/new/labkebiao/showjxbStuList.php?jxb=$jiaoxueban";

// echo $url;
		$content = file_get_contents($url) or die ("sdf");
		$sentense = iconv('GBK', 'UTF-8', $content) or die ("转码失败");
		$mode="/<tr><td>([0-9]*)<\/td><td>(.*)<\/td><td>(.*)<\/td><td>(.*)<\/td>
					<td>(.*)        <\/td><td>(.*)<\/td><td>(.*)<\/td><td>(.*)<\/td><\/tr>/U";
// print_r ($sentense);
		preg_match_all($mode,$sentense,$match);
//		print_r($match);
// echo count($match[1]);
		for ($i=0;$i<=count($match[1])-1;$i++){
			$sql="insert into ref_tclass_student (ref_T_S_Tclass_no,ref_T_S_student_ID,student_type) values ('$jiaoxueban','{$match[3][$i]}','{$match[7][$i]}')";
			$D->exec($sql);
		}
	}
}
function getStuInf($gradeNum,$leibie,$D){
	$url ="http://jwzx.cqupt.edu.cn/pubBjStu.php?zyh=$leibie";
	switch($leibie) {
		case '0190':
			$lei="通信工程专业卓越工程师班";
			break;
		case '0191':
			$lei="通信学院IT精英班";
			break;
		case '0114':
			$lei="通信与信息类";
			break;
	}
	$content = file_get_contents($url) or die ("sdf");
	$sentense = iconv('GBK', 'UTF-8', $content) or die ("转码失败");
	$mode="/<td>&nbsp;(\d{10})<\/td><td>&nbsp;(.{0,})<\/td><td>&nbsp;(.{0,})        <\/td>/U";//获取学生信息
	$mode2="/<td>&nbsp;{$gradeNum}      <\/td><td>&nbsp;{$lei}<\/td><td>&nbsp;(\d{7,8})<\/td>/U";//获取班级号
	preg_match_all($mode2,$sentense,$match);
//	print_r($match);
	foreach($match[1] as $Inf){
//		print_r($Inf);
		$url ="http://jwzx.cqupt.edu.cn/pubBjStu.php?bj=$Inf";
//		echo $url;
		$content = file_get_contents($url) or die ("sdf");
		$sentense = iconv('GBK', 'UTF-8', $content) or die ("转码失败");
		preg_match_all($mode,$sentense,$match1);
		for ($i=0;$i<=count($match1[1])-1;$i++){
			$sql="insert into student (student_name,student_ID,student_sex,student_age,student_class_no,student_password) values ('{$match1[2][$i]}','{$match1[1][$i]}','{$match1[3][$i]}','0','$Inf','{$match1[1][$i]}')";
//			echo $sql;
			$D->exec($sql);
		}
//		print_r($match1);
	}
//	print_r($match);
}



