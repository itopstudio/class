<?php
/**
 * Created by PhpStorm.
 * User: Ewan
 * Date: 2015/8/26
 * Time: 11:31
 */
function setTime($D){
//    echo "1";
    $arr=$_POST;
    $a= "学期为：".$arr['greadInf']."! 该学期起始日期为：".$arr['starDay'];
    return $a;
}